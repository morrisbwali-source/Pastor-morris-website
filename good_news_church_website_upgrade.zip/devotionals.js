
const devotionals = [
{
title: "God's Victory",
text: "But thanks be to God, who always leads us in triumph in Christ. – 2 Corinthians 2:14"
},
{
title: "Walk by Faith",
text: "For we walk by faith, not by sight. – 2 Corinthians 5:7"
},
{
title: "Strength in Christ",
text: "I can do all things through Christ who strengthens me. – Philippians 4:13"
},
{
title: "The Good News",
text: "Go into all the world and preach the gospel. – Mark 16:15"
}
];

const day = new Date().getDay();
const devo = devotionals[day % devotionals.length];

document.getElementById("devotional-box").innerHTML =
"<h3>" + devo.title + "</h3><p>" + devo.text + "</p>";
